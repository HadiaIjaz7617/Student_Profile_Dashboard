import React from 'react';
import StudentCard from './components/StudentCard';
import StudentList from './components/StudentList';
import './App.css';


function App() {
  const students = [
    { name: 'Mehdi', rollNo: '69', grade: 'A+' },
    { name: 'Tasha', rollNo: '43', grade: 'B-' },
    { name: 'Sadii', rollNo: '56', grade: 'A' },
  ];
  return (
    <div className="app-container">
      <h1>Student Dashboard</h1>

    
      <h2>Student Card</h2>
      <StudentCard name="Hameen" rollNo="100" grade="A"  />

      
      <h2> Topper Student</h2>
      <div
        style={{
          width: '450px',            
         height: '150px',
          border: '2px dashed pink',
          borderRadius: '30px',
          padding: '0px',
          margin: '0 auto 9px auto',
          backgroundColor: '#E0F2F1',
        }}
      >
        <h3>Name: Haneen </h3>
        <p>Roll No: 104</p>
        <p>Grade: A++</p>
      </div>

      
      <h2>Student List</h2>
      <StudentList students={students} />
    </div>
  );
}

export default App;
