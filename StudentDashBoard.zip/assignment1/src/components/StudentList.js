import React from 'react';
import StudentCard from './StudentCard';
import './StudentList.css';

const StudentList = ({ students }) => {
  return (
    <div className="student-list">
      {students.map((student, index) => (
        <StudentCard
          key={index}
          name={student.name}
          rollNo={student.rollNo}
          grade={student.grade}
        />
      ))}
    </div>
  );
};

export default StudentList;
