import React from 'react';
import './Studentcard.css';

const StudentCard = ({ name, rollNo, grade }) => {
  return (
    <div className="student-card">
      <h3>{name}</h3>
      <p>Roll No: {rollNo}</p>
      <p>Grade: {grade}</p>
    </div>
  );
};

export default StudentCard;
